﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace pingping.Common
{
    public static class CommonConstants
    {
        public static string ACCOUNT_SESSION = "ACCOUNT_SESSION";
    }
}